'use strict'

var varapiv1catsController = require('./apiv1catsControllerService');

module.exports.getCats = function getCats(req, res, next) {
  varapiv1catsController.getCats(req.swagger.params, res, next);
};

module.exports.addCat = function addCat(req, res, next) {
  varapiv1catsController.addCat(req.swagger.params, res, next);
};