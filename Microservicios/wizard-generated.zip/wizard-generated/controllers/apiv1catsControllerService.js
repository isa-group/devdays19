'use strict'

module.exports.getCats = function getCats(req, res, next) {
  res.send({
    message: 'This is the mockup controller for getCats'
  });
};

module.exports.addCat = function addCat(req, res, next) {
  res.send({
    message: 'This is the mockup controller for addCat'
  });
};