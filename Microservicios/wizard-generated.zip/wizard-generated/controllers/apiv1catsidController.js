'use strict'

var varapiv1catsidController = require('./apiv1catsidControllerService');

module.exports.findCatByid = function findCatByid(req, res, next) {
  varapiv1catsidController.findCatByid(req.swagger.params, res, next);
};

module.exports.deleteCat = function deleteCat(req, res, next) {
  varapiv1catsidController.deleteCat(req.swagger.params, res, next);
};

module.exports.updateCat = function updateCat(req, res, next) {
  varapiv1catsidController.updateCat(req.swagger.params, res, next);
};