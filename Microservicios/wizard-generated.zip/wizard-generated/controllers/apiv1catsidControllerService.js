'use strict'

module.exports.findCatByid = function findCatByid(req, res, next) {
  res.send({
    message: 'This is the mockup controller for findCatByid'
  });
};

module.exports.deleteCat = function deleteCat(req, res, next) {
  res.send({
    message: 'This is the mockup controller for deleteCat'
  });
};

module.exports.updateCat = function updateCat(req, res, next) {
  res.send({
    message: 'This is the mockup controller for updateCat'
  });
};