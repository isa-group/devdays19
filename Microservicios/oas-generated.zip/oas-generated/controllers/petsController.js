'use strict'

var varpetsController = require('./petsControllerService');

module.exports.findPets = function findPets(req, res, next) {
  varpetsController.findPets(req.swagger.params, res, next);
};

module.exports.addPet = function addPet(req, res, next) {
  varpetsController.addPet(req.swagger.params, res, next);
};