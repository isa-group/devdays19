'use strict'

var varpetsidController = require('./petsidControllerService');

module.exports.findPetById = function findPetById(req, res, next) {
  varpetsidController.findPetById(req.swagger.params, res, next);
};

module.exports.deletePet = function deletePet(req, res, next) {
  varpetsidController.deletePet(req.swagger.params, res, next);
};