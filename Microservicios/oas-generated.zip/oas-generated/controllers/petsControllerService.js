'use strict'

module.exports.findPets = function findPets(req, res, next) {
  res.send({
    message: 'This is the mockup controller for findPets'
  });
};

module.exports.addPet = function addPet(req, res, next) {
  res.send({
    message: 'This is the mockup controller for addPet'
  });
};