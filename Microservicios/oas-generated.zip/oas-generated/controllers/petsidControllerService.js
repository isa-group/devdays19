'use strict'

module.exports.findPetById = function findPetById(req, res, next) {
  res.send({
    message: 'This is the mockup controller for findPetById'
  });
};

module.exports.deletePet = function deletePet(req, res, next) {
  res.send({
    message: 'This is the mockup controller for deletePet'
  });
};